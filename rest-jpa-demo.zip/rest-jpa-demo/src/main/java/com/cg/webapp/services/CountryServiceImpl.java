package com.cg.webapp.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.cg.webapp.dao.ICountryDAO;
import com.cg.webapp.models.Country;
import com.cg.webapp.utils.NoCountryFoundException;

@Service
public class CountryServiceImpl implements ICountryService {

	@Autowired private ICountryDAO dao;
	
	@Override
	public Country findByCode(String code) {
		System.out.println("Invoking dao.findById "+code);
		Optional<Country> country = dao.findById(code);
		if(! country.isPresent()) {
			throw new NoCountryFoundException(code);
		}
		return country.get();
	}

	@Override
	public void save(Country country) {
		System.out.println("Invoking dao.save");
		dao.save(country);
	}

	@Override
	public List<Country> findAll() {
		System.out.println("Invoking dao.findAll");
		return dao.findAll();
	}

	@Override
	public void delete(String id) {
		// TODO Auto-generated method stub
		System.out.println("Invoking dao.deleteById");
		dao.deleteById(id);
		
	}

	@Override
	public List<Country> sort(Sort name) {
		// TODO Auto-generated method stub
		System.out.println("Sorting");
		return dao.findAll(name);
		}

}
