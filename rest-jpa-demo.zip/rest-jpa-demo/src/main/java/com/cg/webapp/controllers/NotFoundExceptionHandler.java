/**
 * 
 */
package com.cg.webapp.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

/**
 * @author agupt166
 *
 */
@ControllerAdvice
public class NotFoundExceptionHandler{
	
	@ExceptionHandler({Exception.class})
	public ResponseEntity<String> handleConflict(Exception e,WebRequest req){
		String msg = e.getMessage();
		return new ResponseEntity<String>(msg,HttpStatus.NOT_FOUND);
	}
	
	
}
